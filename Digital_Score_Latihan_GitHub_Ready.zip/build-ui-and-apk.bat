@echo off
setlocal
cd /d "%~dp0ui"
echo [1/2] Installing React UI dependencies...
call npm install --no-audit --no-fund
if errorlevel 1 goto failed
echo [2/2] Building React UI for Android WebView...
call npm run build
if errorlevel 1 goto failed
if not exist "%~dp0app\src\main\assets\index.html" goto missing
for %%A in ("%~dp0app\src\main\assets\index.html") do set SIZE=%%~zA
if "%SIZE%"=="0" goto missing
findstr /C:"dsps-build" "%~dp0app\src\main\assets\index.html" >nul
if errorlevel 1 goto stale
 echo.
echo React bundle verified: app\src\main\assets\index.html (%SIZE% bytes)
echo Next: Open this project in Android Studio and build the APK.
pause
exit /b 0
:stale
echo ERROR: Android assets still contain the fallback or an old bundle.
echo Run the React build again and verify the dsps-build marker.
exit /b 1
:missing
echo ERROR: React bundle was not generated in Android assets.
exit /b 1
:failed
echo Build failed. Check Node.js, npm, and internet connection.
pause
exit /b 1
