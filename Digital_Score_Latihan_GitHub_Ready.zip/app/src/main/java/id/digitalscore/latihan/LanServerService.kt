package id.digitalscore.latihan

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.Handler
import android.os.Looper
import androidx.core.app.NotificationCompat
import fi.iki.elonen.NanoHTTPD
import fi.iki.elonen.NanoWSD
import org.json.JSONObject
import java.net.NetworkInterface
import java.io.IOException
import java.nio.charset.Charset
import java.util.Collections
import java.util.concurrent.CopyOnWriteArraySet
import java.util.UUID

class LanServerService : Service() {
    private var server: ScoreLanServer? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val retryHandler = Handler(Looper.getMainLooper())
    private var retryAttempt = 0
    private val retryRunnable = Runnable { startServer() }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification("Menyiapkan server lokal…"))
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "DigitalScore:LanServer")
        wakeLock?.acquire()
        // Partial WakeLock keeps the CPU available for the user-started LAN session.
        // Wi-Fi itself remains managed by Android; no aggressive high-performance Wi-Fi lock is held.
        startServer()
    }

    private fun startServer() {
        if (server != null) return
        var candidate: ScoreLanServer? = null
        try {
            candidate = ScoreLanServer(this)
            candidate.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false)
            server = candidate
            retryAttempt = 0
            val ip = getLanIpAddresses().firstOrNull() ?: "Hotspot belum terdeteksi"
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NOTIFICATION_ID, buildNotification("Server aktif · http://$ip:8080"))
        } catch (_: Exception) {
            // Dispose the candidate too: its timer handler must not leak if binding the port fails.
            try { candidate?.stop() } catch (_: Exception) { }
            server = null
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NOTIFICATION_ID, buildNotification("Server belum aktif · mencoba ulang otomatis"))
            retryHandler.removeCallbacks(retryRunnable)
            val delay = (2000L * (1L shl retryAttempt.coerceAtMost(4))).coerceAtMost(30000L)
            retryAttempt++
            retryHandler.postDelayed(retryRunnable, delay)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_SERVER) {
            stopSelf()
            return START_NOT_STICKY
        }
        startServer()
        // Android may recreate this user-started service after process pressure.
        // Force-stop by the user is intentionally not bypassed.
        return START_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // Server sengaja tetap berjalan saat activity dihapus dari recent apps.
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        retryHandler.removeCallbacks(retryRunnable)
        try { server?.stop() } catch (_: Exception) { }
        server = null
        if (wakeLock?.isHeld == true) wakeLock?.release()
        wakeLock = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "Server Digital Score", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(message: String): Notification {
        val stopIntent = Intent(this, LanServerService::class.java).setAction(ACTION_STOP_SERVER)
        val stopPending = PendingIntent.getService(
            this, 8128, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Digital Score Latihan")
            .setContentText(message)
            .setSmallIcon(android.R.drawable.stat_sys_upload_done)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(android.R.drawable.ic_media_pause, "Hentikan server", stopPending)
            .build()
    }

    private fun getLanIpAddresses(): List<String> {
        val found = mutableListOf<String>()
        try {
            val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces()).sortedBy { intf ->
                val n = intf.name.lowercase()
                when { n.contains("wlan") || n.contains("ap") || n.contains("swlan") -> 0; n.contains("rmnet") -> 2; else -> 1 }
            }
            for (intf in interfaces) {
                if (!intf.isUp || intf.isLoopback) continue
                for (addr in Collections.list(intf.inetAddresses)) {
                    val ip = addr.hostAddress ?: continue
                    if (addr is java.net.Inet4Address && !addr.isLoopbackAddress && !ip.startsWith("169.254.")) found.add(ip)
                }
            }
        } catch (_: Exception) { }
        return found.distinct()
    }

    companion object {
        private const val CHANNEL_ID = "dsps_lan_server"
        private const val NOTIFICATION_ID = 8127
        private const val ACTION_STOP_SERVER = "id.digitalscore.latihan.STOP_SERVER"
    }
}

private class ScoreLanServer(private val service: LanServerService) : NanoWSD(8080) {
    private val clients = CopyOnWriteArraySet<WebSocket>()
    private val stateLock = Any()
    private val prefs by lazy { service.getSharedPreferences("dsps_lan", android.content.Context.MODE_PRIVATE) }
    private val pairingToken: String by lazy {
        prefs.getString("pairing_token", null) ?: UUID.randomUUID().toString().replace("-", "").also {
            prefs.edit().putString("pairing_token", it).commit()
        }
    }
    private val timerHandler = Handler(Looper.getMainLooper())
    private var lastPublishedSecond: Long = Long.MIN_VALUE
    private val timerTick = object : Runnable {
        override fun run() {
            tickAuthoritativeTimer()
            timerHandler.postDelayed(this, 250L)
        }
    }
    @Volatile private var latestState: JSONObject = run {
        val saved = prefs.getString("latest_state", null)
        try {
            if (saved.isNullOrBlank()) emptyState() else JSONObject(saved)
        } catch (_: Exception) { emptyState() }
    }

    init {
        // Restores the last snapshot immediately. If a timer was running while Android
        // reclaimed the process, the persisted wall-clock deadline determines remaining time.
        timerHandler.post(timerTick)
    }

    private fun emptyState() = JSONObject()
        .put("match", JSONObject.NULL)
        .put("revision", 0L)
        .put("updatedAt", System.currentTimeMillis())

    private fun tickAuthoritativeTimer() {
        var changed: JSONObject? = null
        var ended = false
        synchronized(stateLock) {
            try {
                val match = latestState.optJSONObject("match") ?: return
                if (!match.optBoolean("running", false)) return
                val deadline = match.optLong("deadline", 0L)
                if (deadline <= 0L) return
                val left = kotlin.math.max(0L, kotlin.math.ceil((deadline - System.currentTimeMillis()) / 1000.0).toLong())
                val old = match.optLong("remaining", -1L)
                if (left == old && left > 0L) return
                match.put("remaining", left.toInt())
                if (left <= 0L) {
                    match.put("running", false)
                    match.put("deadline", JSONObject.NULL)
                    match.put("roundDone", true)
                    ended = true
                }
                changed = JSONObject()
                    .put("match", match)
                    .put("revision", latestState.optLong("revision", 0L) + 1L)
                    .put("updatedAt", System.currentTimeMillis())
                latestState = changed!!
            } catch (_: Exception) { return }
        }
        changed?.let { state ->
            val second = System.currentTimeMillis() / 1000L
            if (second != lastPublishedSecond || ended) {
                lastPublishedSecond = second
                persistAndBroadcast(state, durable = ended)
            }
        }
    }

    private fun persistAndBroadcast(state: JSONObject, durable: Boolean = false) {
        // Timer ticks are persisted asynchronously; scoring actions and round completion
        // use commit() so an abrupt process death is less likely to lose the latest result.
        val editor = prefs.edit().putString("latest_state", state.toString())
        if (durable) editor.commit() else editor.apply()
        val msg = JSONObject().put("type", "state").put("payload", state).toString()
        clients.forEach { client -> try { client.send(msg) } catch (_: Exception) { clients.remove(client) } }
    }

    override fun serveHttp(session: IHTTPSession): Response {
        val path = session.uri
        if (path == "/api/health") {
            val snapshot = latestState
            val out = JSONObject().put("ok", true)
                .put("app", "Digital Score Latihan Android")
                .put("appVersion", "1.6.0")
                .put("clients", clients.size)
                .put("timerAuthority", "android-service")
                .put("revision", snapshot.optLong("revision", 0L))
                .put("updatedAt", snapshot.optLong("updatedAt"))
            return json(out.toString())
        }
        if (path == "/api/pairing") {
            // Pairing secrets are exposed only to the local operator WebView.
            if (!isLoopbackRequest(session)) return forbiddenLocalOnly()
            return json(JSONObject().put("ok", true).put("token", pairingToken).put("port", 8080).toString())
        }
        if (path == "/api/pairing/verify") {
            val valid = handshakeQueryToken(session) == pairingToken
            return newFixedLengthResponse(if (valid) Response.Status.OK else Response.Status.FORBIDDEN,
                "application/json; charset=utf-8", JSONObject().put("ok", valid).toString())
        }
        if (path == "/api/state" && session.method == Method.GET) {
            if (!isLoopbackRequest(session)) return forbiddenLocalOnly()
            return json(JSONObject().put("ok", true).put("payload", latestState).toString())
        }
        if (path == "/api/timer" && session.method == Method.POST) {
            if (!isLoopbackRequest(session)) return forbiddenLocalOnly()
            return try {
                val files = HashMap<String, String>()
                session.parseBody(files)
                val action = JSONObject(files["postData"] ?: "{}").optString("action")
                var accepted = false
                synchronized(stateLock) {
                    val match = latestState.optJSONObject("match")
                    if (match != null && !match.optBoolean("finished", false) && !match.optBoolean("roundDone", false)) {
                        when (action) {
                            "start" -> {
                                if (!match.optBoolean("running", false)) {
                                    val remaining = match.optLong("remaining", match.optLong("duration", 120L)).coerceAtLeast(0L)
                                    if (remaining > 0L) {
                                        match.put("running", true)
                                        match.put("deadline", System.currentTimeMillis() + remaining * 1000L)
                                        accepted = true
                                    }
                                }
                            }
                            "pause" -> {
                                if (match.optBoolean("running", false)) {
                                    val deadline = match.optLong("deadline", 0L)
                                    val left = kotlin.math.max(0L, kotlin.math.ceil((deadline - System.currentTimeMillis()) / 1000.0).toLong())
                                    match.put("remaining", left.toInt())
                                    match.put("running", false)
                                    match.put("deadline", JSONObject.NULL)
                                    accepted = true
                                }
                            }
                        }
                        if (accepted) {
                            latestState = JSONObject()
                                .put("match", match)
                                .put("revision", latestState.optLong("revision", 0L) + 1L)
                                .put("updatedAt", System.currentTimeMillis())
                        }
                    }
                }
                if (accepted) persistAndBroadcast(latestState, durable = true)
                json(JSONObject().put("ok", true).put("accepted", accepted)
                    .put("payload", latestState).toString())
            } catch (e: Exception) {
                newFixedLengthResponse(Response.Status.BAD_REQUEST, MIME_PLAINTEXT, "Invalid timer command: ${e.message}")
            }
        }
        if (path == "/api/state" && session.method == Method.POST) {
            if (!isLoopbackRequest(session)) return forbiddenLocalOnly()
            return try {
                val files = HashMap<String, String>()
                session.parseBody(files)
                val data = JSONObject(files["postData"] ?: "{}")
                val incoming = data.optJSONObject("match")
                var accepted = false
                synchronized(stateLock) {
                    val currentEnvelope = latestState
                    val current = currentEnvelope.optJSONObject("match")
                    val candidate = incoming?.let { JSONObject(it.toString()) }
                    if (candidate == null) {
                        latestState = JSONObject().put("match", JSONObject.NULL)
                            .put("revision", currentEnvelope.optLong("revision", 0L) + 1L)
                            .put("updatedAt", System.currentTimeMillis())
                        accepted = true
                    } else {
                        val sameMatch = current != null &&
                            current.optJSONObject("red")?.optString("id") == candidate.optJSONObject("red")?.optString("id") &&
                            current.optJSONObject("blue")?.optString("id") == candidate.optJSONObject("blue")?.optString("id") &&
                            current.optString("startedAt", "") == candidate.optString("startedAt", "")
                        if (sameMatch) {
                            // The native service owns timer fields. A delayed WebView write may
                            // update scores/actions but cannot rewind a native deadline or round.
                            val nativeRound = current!!.optInt("round", 1)
                            val incomingRound = candidate.optInt("round", 1)
                            if (incomingRound < nativeRound ||
                                (current.optBoolean("roundDone", false) && candidate.optBoolean("running", false))) {
                                // Reject stale timer transition; keep current snapshot intact.
                            } else {
                                if (incomingRound == nativeRound) {
                                    listOf("running", "deadline", "remaining", "roundDone").forEach { key ->
                                        if (current.has(key)) candidate.put(key, current.opt(key))
                                    }
                                    if (current.optBoolean("roundDone", false)) {
                                        candidate.put("roundDone", true).put("running", false).put("deadline", JSONObject.NULL)
                                    }
                                }
                                // A higher round is a deliberate operator transition and may
                                // carry its own fresh timer values from the host UI.
                                latestState = JSONObject()
                                    .put("match", candidate)
                                    .put("revision", currentEnvelope.optLong("revision", 0L) + 1L)
                                    .put("updatedAt", System.currentTimeMillis())
                                accepted = true
                            }
                        } else {
                            latestState = JSONObject()
                                .put("match", candidate)
                                .put("revision", currentEnvelope.optLong("revision", 0L) + 1L)
                                .put("updatedAt", System.currentTimeMillis())
                            accepted = true
                        }
                    }
                }
                if (accepted) persistAndBroadcast(latestState, durable = true)
                json(JSONObject().put("ok", true).put("accepted", accepted)
                    .put("revision", latestState.optLong("revision", 0L))
                    .put("updatedAt", latestState.optLong("updatedAt")).toString())
            } catch (e: Exception) {
                newFixedLengthResponse(Response.Status.BAD_REQUEST, MIME_PLAINTEXT, "Invalid JSON: ${e.message}")
            }
        }
        if (path == "/" || path == "/operator") {
            val html = service.assets.open("index.html").bufferedReader(Charset.forName("UTF-8")).use { it.readText() }
            return newFixedLengthResponse(Response.Status.OK, "text/html; charset=utf-8", html)
        }
        if (path == "/monitor") {
            if (handshakeQueryToken(session) != pairingToken) {
                return newFixedLengthResponse(Response.Status.FORBIDDEN, "text/plain; charset=utf-8", "QR pairing tidak valid atau sudah berubah. Pindai ulang dari HP operator.")
            }
            val html = service.assets.open("index.html").bufferedReader(Charset.forName("UTF-8")).use { it.readText() }
            return newFixedLengthResponse(Response.Status.OK, "text/html; charset=utf-8", html)
        }
        return newFixedLengthResponse(Response.Status.NOT_FOUND, MIME_PLAINTEXT, "Not found")
    }

    override fun stop() {
        timerHandler.removeCallbacks(timerTick)
        super.stop()
    }

    override fun openWebSocket(handshake: IHTTPSession): WebSocket {
        if (handshakeQueryToken(handshake) != pairingToken) throw IOException("Pairing token tidak valid")
        return object : WebSocket(handshake) {
            override fun onOpen() {
                clients.add(this)
                try { send(JSONObject().put("type", "state").put("payload", latestState).toString()) }
                catch (_: Exception) { clients.remove(this) }
            }
            override fun onClose(code: WebSocketFrame.CloseCode?, reason: String?, initiatedByRemote: Boolean) { clients.remove(this) }
            override fun onMessage(message: WebSocketFrame) { }
            override fun onPong(pong: WebSocketFrame) { }
            override fun onException(exception: IOException) { clients.remove(this) }
        }
    }

    private fun handshakeQueryToken(session: IHTTPSession): String? =
        session.parms["token"] ?: session.parameters["token"]?.firstOrNull()

    private fun isLoopbackRequest(session: IHTTPSession): Boolean {
        val remote = session.remoteIpAddress.substringBefore('%').lowercase()
        return remote == "127.0.0.1" || remote == "::1" || remote == "0:0:0:0:0:0:0:1"
    }

    private fun forbiddenLocalOnly(): Response = newFixedLengthResponse(
        Response.Status.FORBIDDEN,
        "application/json; charset=utf-8",
        JSONObject().put("ok", false).put("error", "Endpoint operator hanya tersedia dari perangkat host").toString()
    )

    private fun json(value: String): Response =
        newFixedLengthResponse(Response.Status.OK, "application/json; charset=utf-8", value)
}
