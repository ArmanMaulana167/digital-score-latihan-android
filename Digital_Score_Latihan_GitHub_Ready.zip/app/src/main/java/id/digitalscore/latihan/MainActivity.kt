package id.digitalscore.latihan

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.widget.FrameLayout
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity
import android.view.View
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.net.NetworkInterface
import java.util.Collections

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var loading: TextView
    private val mainHandler = Handler(Looper.getMainLooper())
    private var loadAttempts = 0
    @Volatile private var mainFrameLoadFailed = false
    private val loadRunnable = object : Runnable {
        override fun run() {
            if (!::web.isInitialized) return
            loadAttempts++
            mainFrameLoadFailed = false
            web.loadUrl("http://127.0.0.1:8080/")
            if (loadAttempts < 12) mainHandler.postDelayed(this, 900)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNotificationPermission()
        val root = FrameLayout(this).apply { setBackgroundColor(Color.rgb(9, 12, 18)) }
        loading = TextView(this).apply {
            text = "DIGITAL SCORE LATIHAN\n\nMenyiapkan arena…"
            setTextColor(Color.rgb(226, 198, 132))
            textSize = 16f
            gravity = Gravity.CENTER
        }
        web = WebView(this).apply {
            setBackgroundColor(Color.rgb(9, 12, 18))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.mediaPlaybackRequiresUserGesture = true
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    if (!mainFrameLoadFailed) {
                        mainHandler.removeCallbacks(loadRunnable)
                        loading.visibility = View.GONE
                        web.visibility = View.VISIBLE
                    }
                }
                override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: android.webkit.WebResourceError?) {
                    if (request?.isForMainFrame == true) {
                        mainFrameLoadFailed = true
                        loading.visibility = View.VISIBLE
                        loading.text = "DIGITAL SCORE LATIHAN\n\nMenghubungkan ke server lokal…"
                    }
                }
            }
            visibility = View.INVISIBLE
            addJavascriptInterface(HostBridge(), "AndroidHost")
        }
        root.addView(web, FrameLayout.LayoutParams(-1, -1))
        root.addView(loading, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        ContextCompat.startForegroundService(this, Intent(this, LanServerService::class.java))
        mainHandler.postDelayed(loadRunnable, 250)
    }

    private inner class HostBridge {
        @JavascriptInterface fun getLanIp(): String = lanIp()
        @JavascriptInterface fun getAppVersion(): String = "1.6.0"
    }

    private fun lanIp(): String {
        return try {
            val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces())
            val ranked = interfaces.sortedBy { intf ->
                val n = intf.name.lowercase()
                when { n.contains("wlan") || n.contains("ap") || n.contains("swlan") -> 0; n.contains("rmnet") -> 2; else -> 1 }
            }
            ranked.asSequence().filter { it.isUp && !it.isLoopback }
                .flatMap { Collections.list(it.inetAddresses).asSequence() }
                .firstOrNull { it is java.net.Inet4Address && !it.isLoopbackAddress && !it.hostAddress.orEmpty().startsWith("169.254.") }
                ?.hostAddress ?: "IP-belum-terbaca"
        } catch (_: Exception) { "IP-belum-terbaca" }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            AlertDialog.Builder(this)
                .setTitle("Izinkan notifikasi server")
                .setMessage("Digital Score perlu menampilkan notifikasi permanen saat sesi latihan aktif. Notifikasi ini memberi tahu bahwa server lokal dan koneksi monitor sedang berjalan, termasuk ketika layar HP dikunci. Izin ini tidak mengakses pesan atau data pribadi.")
                .setPositiveButton("Izinkan") { _, _ ->
                    ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 41)
                }
                .setNegativeButton("Nanti", null)
                .show()
        }
    }

    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        mainHandler.removeCallbacks(loadRunnable)
        if (::web.isInitialized) web.destroy()
        super.onDestroy()
    }
}
