# Stage 2 — Uji timer Android native

## Tujuan
Memastikan timer tidak bergantung pada JavaScript WebView ketika layar host terkunci.

## Skenario uji perangkat
1. Buka aplikasi host dan mulai sesi.
2. Mulai timer 60 detik. Kunci layar selama 20 detik.
3. Buka HP host: sisa waktu harus sekitar 40 detik (toleransi kecil untuk waktu buka layar).
4. Sambungkan HP monitor, mulai timer, lalu kunci layar host. Monitor harus tetap menerima perubahan sisa waktu.
5. Biarkan timer mencapai 00:00 saat host terkunci. Monitor harus menerima `running=false`, `remaining=0`, dan `roundDone=true`.
6. Buka kembali host: tampilan harus sinkron dengan snapshot server.
7. Uji service/process restart secara terkontrol; jika service direstart ketika timer berjalan, deadline harus tetap dihitung dari waktu absolut yang tersimpan.
8. Uji Force Stop secara terpisah: Android tidak menjanjikan restart otomatis setelah Force Stop; buka aplikasi lagi untuk memulai service.

## Lulus jika
- Timer tidak kembali ke angka sebelumnya setelah layar dibuka.
- Timer tidak bertambah ketika service dibuat ulang.
- Monitor menerima snapshot timer dan status ronde selesai.
- Tidak ada dua timer aktif yang berjalan bersamaan.

Catatan: checklist ini belum dijalankan pada perangkat fisik.
