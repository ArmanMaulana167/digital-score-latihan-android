from pathlib import Path
import json, re, sys, xml.etree.ElementTree as ET
root = Path(__file__).resolve().parent
errors=[]
manifest = root/'app/src/main/AndroidManifest.xml'
try:
    tree=ET.parse(manifest)
    ns={'a':'http://schemas.android.com/apk/res/android'}
    app=tree.getroot().find('application')
    service=app.find('service') if app is not None else None
    if service is None: errors.append('Service LanServerService tidak ditemukan di Manifest')
    else:
        if service.attrib.get('{http://schemas.android.com/apk/res/android}foregroundServiceType') != 'specialUse': errors.append('Foreground service type bukan specialUse')
        if service.attrib.get('{http://schemas.android.com/apk/res/android}stopWithTask') != 'false': errors.append('stopWithTask harus false')
except Exception as e: errors.append(f'Manifest XML tidak valid: {e}')
try:
    pkg=json.loads((root/'ui/package.json').read_text())
    for dep in ['react','react-dom','motion','lucide-react','qrcode.react','vite','typescript','vite-plugin-singlefile']:
        if dep not in {**pkg.get('dependencies',{}), **pkg.get('devDependencies',{})}: errors.append(f'Dependency tidak ada: {dep}')
except Exception as e: errors.append(f'package.json tidak valid: {e}')
service_src=(root/'app/src/main/java/id/digitalscore/latihan/LanServerService.kt').read_text()
for needle, label in [
    ('START_STICKY','START_STICKY'),
    ('PowerManager.PARTIAL_WAKE_LOCK','Partial Wake Lock'),
    ('/api/pairing/verify','endpoint verifikasi pairing'),
    ('openWebSocket','WebSocket'),
    ('isLoopbackRequest(session)','proteksi endpoint host-only'),
    ('timerAuthority','penanda otoritas timer'),
    ('latest_state','snapshot persisten')]:
    if needle not in service_src: errors.append(f'Implementasi tidak ditemukan: {label}')
activity=(root/'app/src/main/java/id/digitalscore/latihan/MainActivity.kt').read_text()
for needle in ['startForegroundService','addJavascriptInterface','getLanIp']:
    if needle not in activity: errors.append(f'Activity tidak memuat {needle}')
ui=(root/'ui/src/main.tsx').read_text()
for needle in ['QRCodeSVG','/api/timer','/api/state','/ws?token=','/monitor']:
    if needle not in ui: errors.append(f'UI tidak memuat integrasi {needle}')
assets=(root/'app/src/main/assets/index.html').read_text(errors='ignore')
if 'dsps-build' in assets:
    print('INFO: React build marker sudah ditemukan pada Android assets.')
else:
    print('INFO: Android assets saat ini masih fallback HTML; jalankan build-ui-and-apk.bat untuk menghasilkan bundle React.')
if errors:
    print('STAGE 5 SOURCE CHECK: FAILED')
    for e in errors: print(' -',e)
    sys.exit(1)
print('STAGE 5 SOURCE CHECK: PASS')
print('Catatan: pemeriksaan ini statis; bukan kompilasi APK atau pengujian perangkat Android.')
