# Cloud Build APK — Digital Score Latihan v1.6.0

Workflow GitHub Actions tersedia di:

`.github/workflows/android-apk.yml`

Laptop tidak perlu memasang Android Studio atau Android SDK. GitHub-hosted runner akan memasang Node.js 20, Java 17, Android SDK 35, dan Gradle 8.9, lalu:

1. memasang dependency UI React;
2. membangun UI React/Vite ke `app/src/main/assets/index.html`;
3. memverifikasi marker `dsps-build=react-v1.6.0` agar HTML fallback/unbundled tidak lolos;
4. menjalankan `gradle assembleDebug`;
5. mengunggah `app-debug.apk` sebagai workflow artifact selama 14 hari.

## Cara memasukkan source ke repository

1. Buat repository GitHub kosong, misalnya `digital-score-latihan-android`.
2. Ekstrak paket source ini.
3. Buka folder `DSPS_Latihan_Android`.
4. Upload **isi folder tersebut** ke root repository (termasuk folder tersembunyi `.github`). Jangan mengunggah folder induk saja.
5. Commit ke branch `main`.
6. Buka tab **Actions** dan pilih workflow **Build Digital Score Latihan APK**.
7. Tunggu job selesai. Buka run terbaru, lalu unduh artifact `digital-score-latihan-debug-apk`.

Workflow juga mendeteksi bila folder `DSPS_Latihan_Android` diunggah sebagai subfolder repository.

## Catatan rilis

- Output workflow ini adalah **debug APK**, untuk instalasi dan pengujian internal dua HP.
- APK debug belum ditandatangani dengan kunci rilis produk. Jangan membagikannya sebagai APK komersial final.
- Untuk APK release, perlu membuat keystore pribadi dan menyimpan rahasia signing sebagai GitHub Actions Secrets. Jangan pernah memasukkan keystore/password ke repository.
- Build yang sukses hanya membuktikan proses kompilasi berhasil. Itu belum membuktikan WebSocket, timer saat layar terkunci, QR pairing, atau pemulihan berjalan benar di perangkat fisik.
