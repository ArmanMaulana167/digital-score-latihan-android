# Stage 3 — LAN pairing and permission test checklist

- [ ] Fresh install, first-run notification explanation and Android 13+ notification prompt.
- [ ] Confirm the host app requests no location/camera/Bluetooth/phone permissions.
- [ ] Manually enable hotspot; host reports a hotspot/Wi-Fi IPv4 address.
- [ ] `/api/pairing` returns a token and QR includes `?token=...`.
- [ ] Correct QR opens `/monitor?token=...` on second phone.
- [ ] Missing or altered token is rejected by `/monitor`.
- [ ] WebSocket without token is rejected; correct token receives current state.
- [ ] Disconnect/reconnect monitor Wi-Fi; monitor reconnects and receives fresh state.
- [ ] Change host hotspot/IP; operator refreshes QR with the new address.
- [ ] Lock host screen for 10 minutes; server notification remains and monitor stays connected.
- [ ] Deny notification permission; app shows a clear warning and service behavior is checked.
- [ ] Test Android 14+ foreground service startup and notification behavior.
- [ ] Test battery optimization on/off and OEM background restrictions.

Do not mark any physical-device item complete until tested on real phones.
