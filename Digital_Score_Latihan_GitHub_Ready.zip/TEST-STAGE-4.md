# Stage 4 — Recovery & durable match state

## Implemented in source
- Foreground service returns `START_STICKY` for Android process recreation. A user force-stop is not bypassed.
- Server bind failures use bounded exponential retry (2s → 4s → 8s → 16s → 30s). Failed candidate server instances are stopped to release timer callbacks.
- Ongoing notification explains the server state and provides an explicit stop action.
- `stopWithTask=false` keeps the service independent from the Activity task when the user swipes the Activity away (device/vendor behavior still needs testing).
- Latest match snapshot is committed to SharedPreferences after operator state writes and round completion. Timer ticks are persisted asynchronously; the timer deadline is wall-clock based so a recreated service can calculate remaining time.
- Native timer fields are authoritative for the current match/round. Start/pause are explicit `/api/timer` commands handled by Android; a delayed WebView write cannot rewind a running timer, revive an ended round, or overwrite a newer round.
- Health endpoint exposes state revision and connected monitor count. WebSocket clients receive a full snapshot on every connection.

## Physical-device test procedure
1. Install the debug APK on host phone and grant notifications.
2. Enable hotspot manually; start a match and start the timer.
3. Lock the host screen for at least 90 seconds. Confirm monitor countdown continues and the round ends at zero.
4. Swipe the host Activity from Recents (do not force-stop it). Confirm the monitor remains connected.
5. If Android reclaims the process under test conditions, relaunch/observe service recreation. Confirm `/api/health` returns and the previous snapshot is restored.
6. Stop the server using the notification action. Confirm monitor shows disconnected and service notification disappears.
7. Start the app again; confirm server starts and previous match state is recovered.
8. During a running round, temporarily disable Wi-Fi on the monitor, re-enable it, and confirm WebSocket reconnect receives a full current snapshot.
9. Try an invalid pairing token; monitor must be rejected.

## Important limitations
- `START_STICKY` is a restart request, not a guarantee. Android force-stop, reboot, vendor task killers, or battery policies can stop the service. Reboot auto-start is not enabled in this stage.
- The app does not silently turn on hotspot; user enables it in Android Settings/Quick Settings.
- The wall-clock deadline is resilient to process restart but can be affected by manual system clock changes. A later hardening step should use elapsed realtime while the process is alive and reconcile to persisted wall time after restart.
- This source has not been compiled to APK or tested on physical devices in this environment.
