Workflow cloud build APK ada di android-apk.yml.
Lihat CLOUD-BUILD-GITHUB.md untuk cara memasukkan source ke GitHub dan mengambil artifact APK.
