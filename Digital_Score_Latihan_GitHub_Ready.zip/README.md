# Digital Score Latihan Android — v1.6.0 / Stage 5

Proyek universal untuk latihan pencak silat. HP host menjalankan operator + server lokal; HP kedua menjadi monitor browser melalui hotspot yang sama.

## Fokus Stage 5
- Integrasi build React satu-file ke Android WebView.
- Pemeriksaan marker build agar HTML fallback tidak disangka sebagai bundle React terbaru.
- Proteksi endpoint operator (`/api/pairing`, `/api/state`, `/api/timer`) agar hanya dapat dipanggil dari loopback HP host.
- Monitor tetap menggunakan token pairing untuk halaman dan WebSocket.
- Versi proyek dinaikkan menjadi 1.6.0.

## Build
Ikuti `BUILD-APK.txt`. Jalankan `build-ui-and-apk.bat` sebelum membangun APK di Android Studio.

## Verifikasi source
Jalankan:

```bash
python VERIFY-STAGE-5.py
```

Pemeriksaan ini memvalidasi struktur dan integrasi statis. Ini bukan pengganti build Gradle, uji WebView, atau pengujian dua perangkat Android.

## Batasan yang diketahui
- Hotspot tetap diaktifkan pengguna melalui Settings Android.
- `START_STICKY` membantu pemulihan service, tetapi tidak mengalahkan Force Stop atau semua kebijakan vendor.
- Kompilasi APK dan pengujian perangkat nyata harus dilakukan di lingkungan Android Studio dan HP fisik.
